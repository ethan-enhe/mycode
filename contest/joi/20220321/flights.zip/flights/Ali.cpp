#include "Ali.h"
#include <string>
#include <vector>

namespace {

int variable_example = 0;

}

void Init(int N, std::vector<int> U, std::vector<int> V) {
  variable_example++;
  SetID(0, 0);
  SetID(1, 1);
  SetID(2, 2 * N + 19);
}

std::string SendA(std::string S) {
  return "01001";
}
