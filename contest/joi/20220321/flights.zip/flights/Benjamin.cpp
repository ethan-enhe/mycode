#include "Benjamin.h"
#include <string>
#include <vector>

namespace {

int variable_example = 0;

}

std::string SendB(int N, int X, int Y) {
  variable_example++;
  if (X == 0) {
    return "00000000001111111111";
  }
  return "00000111110000011111";
}

int Answer(std::string T) {
  return 1;
}
