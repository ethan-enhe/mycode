#include <string>
#include <vector>

std::string SendB(int N, int X, int Y);

int Answer(std::string T);
