#include <string>
#include <vector>

void Init(int N, std::vector<int> U, std::vector<int> V);

std::string SendA(std::string S);

void SetID(int p, int value);
