#ifdef __cplusplus
extern "C" {
#endif

typoo
(typoo)

int main() {
    printf("hello, world");
    return 0;
}
