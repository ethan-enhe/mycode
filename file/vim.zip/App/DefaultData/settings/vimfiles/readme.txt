The files in this directory are used for storing customizations to
gVim Portable other than those in the _vimrc and _viminfo files.

Custom colorschemes, compilers, syntax files, etc. can go in here;
use the same directory structure as you do in App\vim\vimXX
(e.g. App\vim\vim73\colors\PortableApps.vim would become
      Data\settings\vimfiles\colors\PortableApps.vim).

Do NOT store your customisations in the App directory, otherwise they
will be lost when you upgrade gVim Portable.